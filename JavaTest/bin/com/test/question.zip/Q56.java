package com.test.question;

public class Q56 {
//배열 써도되고 안써도됨
}
