package com.test.question;

public class Q08 {
	
	public static void main(String[] args) {
		
		hello();
		introduce();
		bye();
		
		
	}

	private static void bye() {
		System.out.println("안녕히가세요.");
		
	}

	private static void introduce() {
		System.out.println("저는 홍길동입니다.");
		
	}

	private static void hello() {
		System.out.println("안녕하세요.");
		
	}

}
