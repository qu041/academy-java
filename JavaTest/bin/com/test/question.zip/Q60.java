package com.test.question;

public class Q60 {
	
	public static void main(String[] args) {
		// 0 + 1 + 1 + 2 + 3 + 5 + ....+ 89 + =232
		// n-1 + n + = 2n-1
		
		for (; i <100;) {
			sum += i;
		}
	
	
	
	
	}
	
	
	

}
