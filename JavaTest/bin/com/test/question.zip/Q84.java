package com.test.question;

public class Q84 {
	
	public static void main(String[] args) {
		
		String content = "안녕~길동아~잘가~길동아~";
		String word = "길동";
		int count = 0;
		
		
		}
		System.out.printf("'%s'을 총 %d회 발견했습니다.\n", word,count);
	}

}
