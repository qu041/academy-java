package com.test.question;

public class Q07 {

	public static void main(String[] args) {
		
				/*
				'a' = 97
				'A' = 65
				→ 소문자 - 32 = 대문자
				*/
		
		
		
		
	}
	
}
