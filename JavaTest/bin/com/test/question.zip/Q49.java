package com.test.question;

public class Q49 {
	//여기서부터 다중포문 문제임
}
