package com.test.question;

public class Q54 {
	//for (int i=2 ~ 100) {
	//for (int j=2~ i-1) {
	// if (i % j == 0) {
	//          소수아님
	//  }
	// }
	//}

}
